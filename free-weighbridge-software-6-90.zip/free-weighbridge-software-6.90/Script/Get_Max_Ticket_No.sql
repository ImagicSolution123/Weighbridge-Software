IF EXISTS (SELECT name FROM sysobjects WHERE name = 'Get_Max_Ticket_No' AND type = 'P')
   DROP PROCEDURE [Get_Max_Ticket_No]
GO
-- Create the stored procedure.
CREATE  PROCEDURE [Get_Max_Ticket_No] 
(	@pCoCode					Int,
	@pYearID					Int,
	@pUserID					Int,
	@pTicket_No				Int = Null output	
)
AS
BEGIN
   
	--Select @pTicket_No = isnull(Max(Ticket_No),0) From tblSlip Where Transaction_Type = @pTransaction_Type	
	--Set @pTicket_No = @pTicket_No + 1
	
	Insert Into tblSlip ( CoCode, YearID, UserID,  EntryDate  ) 
			Values 
		( @pCoCode, @pYearID, @pUserID, GetDate())
	Select @pTicket_No = @@IDENTITY	
END
GO

--DECLARE @pTicket_No	 varchar(200)
--DECLARE @pSlip_Code	 varchar(200)		
--exec Get_Max_Slip_Ticket_No 1,1,1, @pTicket_No Output,  @pSlip_Code	Output
--
--Select  @pTicket_No
--Select  @pSlip_Code
--
--select top 1 * FRom tblSLip	order by SlipCode desc