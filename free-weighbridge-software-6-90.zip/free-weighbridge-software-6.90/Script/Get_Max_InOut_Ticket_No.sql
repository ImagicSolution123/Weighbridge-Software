IF EXISTS (SELECT name FROM sysobjects WHERE name = 'Get_Max_InOut_Ticket_No' AND type = 'P')
   DROP PROCEDURE [Get_Max_InOut_Ticket_No]
GO
-- Create the stored procedure.
CREATE PROCEDURE [dbo].[Get_Max_InOut_Ticket_No] 
(	@pCoCode					Int,
	@pYearID					Int,
	@pUserID					Int,
	@InOut_Type_code					Int,
	@pTicket_No				Int = Null output	
)
AS
BEGIN
   
	Select @pTicket_No = isnull(Max(Ticket_No),0) From tblSlip Where InOut_Type_Code = @InOut_Type_code	
	Set @pTicket_No = @pTicket_No + 1
	
	Insert Into tblSlip (Ticket_No, CoCode, YearID, UserID,  EntryDate ,InOut_Type_Code ) 
			Values 
		(@pTicket_No, @pCoCode, @pYearID, @pUserID, GetDate(),@InOut_Type_code	)
	Select @pTicket_No = @pTicket_No	
END

---ALTER TABLE tblSLip ADD CONSTRAINT PK_DatabaseList PRIMARY KEY (Ticket_No, InOut_Type_Code)