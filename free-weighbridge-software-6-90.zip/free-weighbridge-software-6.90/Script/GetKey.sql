IF EXISTS (SELECT name FROM sysobjects      WHERE name = 'GetKey' AND type = 'P')
   DROP PROCEDURE GetKey
GO
-- Create the stored procedure.
CREATE  PROCEDURE [dbo].[GetKey] @Val integer = null output
AS
DECLARE @iKey1 integer,  @iKey integer 
BEGIN
    -- Insert statements for procedure here
	 SELECT  @iKey = iKey From tblKey
	
	Select @Val = @iKey	
	set @iKey1  = @iKey + 1  
	
	update tblKey set iKey = @iKey1
END
GO
--insert Into tblKey(iKey) Values(2000)